const express = require("express")
const bodyParser = require("body-parser")
const request = require("request")
const https = require("https")

const app = express()

app.use(express.static("public")) //implement css and images to local web via static
app.use(bodyParser.urlencoded({extended: true}))

app.get('/', (req, res) =>{
    res.sendFile(__dirname + "/signup.html")
})

app.post('/', (req, res) => { //accessing input data, storing it into the mailchimp api 
    const firstName = req.body.fName
    const lastName = req.body.lName
    const email = req.body.email

    const data = {
        members: [
            {
                email_address: email,
                status: "subscribed",
                merge_fields: {
                    FNAME: firstName,
                    LNAME: lastName
                }
            }
        ]

    };

    const jsonData = JSON.stringify(data) //turn data into string in format of json
    const url = "https://us10.api.mailchimp.com/3.0/lists/5e37aa500a"
    const options = {
        method: "POST",
        auth: "kaiser14:a94f09f10503be888ab7c209bbc5343a-us10"

    }

    const request = https.request(url, options, (response) =>
    {
        if(response.statusCode === 200){
            res.sendFile(__dirname + "/success.html")
        }

        else{
    
            res.sendFile(__dirname + "/failure.html")
        }


        response.on("data", (data) =>{
            console.log(JSON.parse(data))
        })
    })

    request.write(jsonData)
    request.end()

})

app.post("/failure", (req, res) =>{ //takes back user back to sign up page when failure happens
    res.redirect("/")
})

app.listen(process.env.PORT || 1000, function(){ //heroku server system
    console.log("Server Heroku and 1000 is live")
})


//start server by using "nodemon run app.js"
//API Key
//a94f09f10503be888ab7c209bbc5343a-us10

//below is audience id or unique id
//5e37aa500a
